# SpamSms
Spam sms (NEW UPDATE)

# How To Use
> PYTHON 3.X
```
apt update && pkg upgrade
apt install python
apt install git
git clone https://github.com/KANG-NEWBIE/SpamSms
pip install requests mechanize bs4
cd SpamSms
python main.py
```
